import { MongoClient } from "mongodb";
import fs from "fs";
let data = {};
// Replace the uri string with your MongoDB deployment's connection string.
let gallery;
//We read from file
fs.readFile('gallery.json', 'utf8', function(err,data){
  gallery = JSON.parse(data);
});
const uri = "mongodb://127.0.0.1:27017/";
// Create a new client and connect to MongoDB
const client = new MongoClient(uri);
async function run() {
  try {
    //We connect a database and collection
    //This is just mongo stuff
    const database = client.db("gallery");
    const galleryCollection = database.collection("gallerycollections");
    
  //this would refresh, starting from new
	const result1 = await galleryCollection.drop();

	if(result1){
		console.log("Cards collection has been dropped.")
	}

    const result = await galleryCollection.insertMany(gallery);

    console.log("Successfuly inserted " + result.insertedCount);
  } finally {
     // Close the MongoDB client connection
    await client.close();
  }
}
// Run the function and handle any errors
run().catch(console.dir);